angular.module('colorboxdemo', [
    'colorboxdemo.controllers',
    'colorbox',
    'ezplus'
]);
